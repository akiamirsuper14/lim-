#!/usr/bin/env python3
"""
Генератор ресурсов мода Liminal Spaces (ничего скачивать не надо).
Создаёт:
  - 16x16 PNG-текстуры всех блоков  -> src/main/resources/assets/liminalspaces/textures/block/
  - blockstates и модели блоков      -> assets/liminalspaces/blockstates, models/block
  - loot-таблицы (блок дропает себя) -> data/liminalspaces/loot_tables/blocks/
Запуск: python3 tools/gen_textures.py   (нужен Pillow: pip install pillow)
"""
import json
import os
import random

try:
    from PIL import Image, ImageDraw
except ImportError:
    raise SystemExit("Установите Pillow: pip install pillow")

ROOT = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources")
TEX = os.path.join(ROOT, "assets", "liminalspaces", "textures", "block")
BS = os.path.join(ROOT, "assets", "liminalspaces", "blockstates")
MODEL = os.path.join(ROOT, "assets", "liminalspaces", "models", "block")
LOOT = os.path.join(ROOT, "data", "liminalspaces", "loot_tables", "blocks")

for d in (TEX, BS, MODEL, LOOT):
    os.makedirs(d, exist_ok=True)

rng = random.Random(1337)


def noise_tex(base, vary=24, speckles=None, seed=0):
    """Базовый цвет + шум пикселей + опциональные вкрапления."""
    r = random.Random(seed)
    img = Image.new("RGB", (16, 16), base)
    px = img.load()
    for y in range(16):
        for x in range(16):
            dv = r.randint(-vary, vary)
            px[x, y] = tuple(max(0, min(255, c + dv)) for c in base)
    if speckles:
        for color, count in speckles:
            for _ in range(count):
                x, y = r.randint(0, 15), r.randint(0, 15)
                px[x, y] = color
    return img


def draw_on(img, fn):
    d = ImageDraw.Draw(img)
    fn(d)
    return img


# ----------------------------------------------------------------------------
# Текстуры: имя -> функция генерации
# ----------------------------------------------------------------------------
TEXTURES = {}

def tex(name):
    def deco(fn):
        TEXTURES[name] = fn
        return fn
    return deco

# общие / служебные
@tex("exit_sign")
def _( ): return draw_on(noise_tex((30, 30, 30), 6, seed=1), lambda d: (
    d.rectangle([1, 2, 14, 13], outline=(255, 60, 60), width=1),
    d.text((3, 5), "EXIT", fill=(255, 80, 80))))

@tex("portal_forward")
def _(): return noise_tex((90, 200, 255), 40, seed=2)

@tex("portal_back")
def _(): return noise_tex((255, 170, 60), 40, seed=3)

@tex("portal_wake")
def _(): return noise_tex((220, 120, 255), 40, seed=4)

@tex("vending_machine")
def _(): return draw_on(noise_tex((150, 30, 35), 10, seed=5), lambda d: (
    d.rectangle([2, 2, 13, 9], outline=(220, 220, 220), width=1),
    d.rectangle([3, 3, 7, 8], fill=(60, 60, 70)),
    d.rectangle([9, 3, 12, 8], fill=(200, 200, 210)),
    d.rectangle([2, 11, 13, 14], fill=(40, 40, 45))))

@tex("cloud")
def _(): return noise_tex((235, 235, 240), 10, seed=6)

@tex("safe_platform")
def _(): return noise_tex((120, 120, 130), 12, seed=7)

# измерение 1
@tex("dark_grass")
def _(): return noise_tex((28, 26, 38), 10, speckles=[((45, 42, 60), 12)], seed=8)

@tex("playground_platform")
def _(): return noise_tex((230, 130, 40), 14, seed=9)

@tex("playground_border")
def _(): return noise_tex((70, 40, 120), 14, seed=10)

@tex("tower_red")
def _(): return draw_on(noise_tex((190, 40, 40), 12, seed=11), lambda d: (
    d.rectangle([3, 3, 12, 12], outline=(140, 25, 25), width=1)))

@tex("white_pole")
def _(): return noise_tex((235, 235, 230), 8, seed=12)

@tex("dark_roof")
def _(): return noise_tex((35, 35, 50), 8, seed=13)

@tex("blue_slide")
def _(): return draw_on(noise_tex((40, 110, 220), 12, seed=14), lambda d: (
    d.line([2, 13, 13, 3], fill=(120, 190, 255), width=2)))

@tex("swing_seat")
def _(): return noise_tex((120, 70, 40), 10, seed=15)

# измерение 2
@tex("beige_wallpaper")
def _(): return draw_on(noise_tex((215, 200, 170), 8, seed=16), lambda d: (
    [d.line([0, y, 15, y], fill=(200, 184, 152), width=1) for y in range(3, 16, 4)]))

@tex("white_trim")
def _(): return noise_tex((245, 245, 240), 6, seed=17)

@tex("brown_carpet")
def _(): return noise_tex((110, 70, 45), 12, speckles=[((90, 55, 35), 20)], seed=18)

@tex("ceiling_tile")
def _(): return draw_on(noise_tex((235, 235, 230), 6, seed=19), lambda d: (
    d.line([0, 8, 15, 8], fill=(210, 210, 205), width=1),
    d.line([8, 0, 8, 15], fill=(210, 210, 205), width=1)))

@tex("fluorescent_lamp_on")
def _(): return draw_on(noise_tex((250, 250, 240), 6, seed=20), lambda d: (
    d.rectangle([1, 4, 14, 11], fill=(255, 255, 230), outline=(200, 200, 190), width=1)))

@tex("fluorescent_lamp_off")
def _(): return draw_on(noise_tex((120, 120, 125), 6, seed=21), lambda d: (
    d.rectangle([1, 4, 14, 11], fill=(90, 90, 95), outline=(70, 70, 75), width=1)))

@tex("room_door")
def _(): return draw_on(noise_tex((160, 115, 70), 8, seed=22), lambda d: (
    d.rectangle([2, 1, 13, 14], outline=(120, 85, 50), width=1),
    d.ellipse([10, 7, 12, 9], fill=(220, 200, 140))))

# измерение 3
@tex("asphalt")
def _(): return noise_tex((45, 45, 50), 10, speckles=[((70, 70, 75), 15)], seed=23)

@tex("road_line")
def _(): return draw_on(noise_tex((45, 45, 50), 10, seed=24), lambda d: (
    d.rectangle([0, 6, 15, 9], fill=(240, 240, 230))))

@tex("stop_sign")
def _(): return draw_on(noise_tex((200, 30, 30), 8, seed=25), lambda d: (
    d.polygon([(8, 1), (14, 4), (14, 11), (8, 14), (2, 11), (2, 4)], fill=(210, 35, 35), outline=(255, 255, 255)),
    d.text((4, 6), "STOP", fill=(255, 255, 255))))

@tex("metal_pole")
def _(): return noise_tex((150, 150, 155), 8, seed=26)

# измерение 4
@tex("cabin_wall")
def _(): return noise_tex((225, 228, 220), 8, seed=27)

@tex("cabin_floor")
def _(): return noise_tex((70, 55, 60), 10, seed=28)

@tex("cabin_ceiling")
def _(): return noise_tex((235, 238, 235), 6, seed=29)

@tex("airplane_window")
def _(): return draw_on(noise_tex((140, 200, 245), 6, seed=30), lambda d: (
    d.rectangle([1, 1, 14, 14], outline=(180, 185, 180), width=2),
    d.ellipse([5, 6, 10, 11], fill=(255, 245, 210))))

@tex("airplane_seat")
def _(): return draw_on(noise_tex((60, 150, 160), 10, seed=31), lambda d: (
    d.rectangle([2, 8, 13, 12], fill=(45, 120, 130)),
    d.rectangle([2, 2, 6, 10], fill=(45, 120, 130))))

@tex("blue_light_strip")
def _(): return noise_tex((60, 170, 255), 20, speckles=[((160, 220, 255), 10)], seed=32)

@tex("overhead_handle")
def _(): return draw_on(noise_tex((60, 60, 65), 8, seed=33), lambda d: (
    d.arc([4, 2, 11, 13], 0, 180, fill=(30, 30, 35), width=2)))

# измерение 5
@tex("path_dirt")
def _(): return noise_tex((150, 125, 90), 14, speckles=[((120, 98, 70), 14)], seed=34)

@tex("ivy_house")
def _(): return noise_tex((110, 110, 115), 8, speckles=[((50, 130, 50), 40), ((35, 100, 35), 25)], seed=35)

@tex("dark_doorway")
def _(): return noise_tex((8, 8, 10), 4, seed=36)

# ----------------------------------------------------------------------------
# Запись текстур
# ----------------------------------------------------------------------------
for name, fn in TEXTURES.items():
    fn().save(os.path.join(TEX, name + ".png"))

# ----------------------------------------------------------------------------
# Blockstates + модели
# ----------------------------------------------------------------------------
ALL_BLOCKS = [
    "exit_sign", "portal_forward", "portal_back", "portal_wake", "vending_machine",
    "cloud", "safe_platform",
    "dark_grass", "playground_platform", "playground_border", "tower_red", "white_pole",
    "dark_roof", "blue_slide", "swing_seat",
    "beige_wallpaper", "white_trim", "brown_carpet", "ceiling_tile", "room_door",
    "asphalt", "road_line", "stop_sign", "metal_pole",
    "cabin_wall", "cabin_floor", "cabin_ceiling", "airplane_window", "airplane_seat",
    "blue_light_strip", "overhead_handle",
    "path_dirt", "ivy_house", "dark_doorway",
]

TRANSLUCENT = {"portal_forward", "portal_back", "portal_wake", "cloud"}

for name in ALL_BLOCKS:
    if name == "fluorescent_lamp":
        # handled separately below
        continue
    with open(os.path.join(BS, name + ".json"), "w") as f:
        json.dump({"variants": {"": {"model": f"liminalspaces:block/{name}"}}}, f, indent=2)
    parent = "minecraft:block/cube_translucent" if name in TRANSLUCENT else "minecraft:block/cube_all"
    with open(os.path.join(MODEL, name + ".json"), "w") as f:
        json.dump({"parent": parent, "textures": {"all": f"liminalspaces:block/{name}"}}, f, indent=2)

# люминесцентная лампа: два состояния lit=true/false
with open(os.path.join(BS, "fluorescent_lamp.json"), "w") as f:
    json.dump({"variants": {
        "lit=true": {"model": "liminalspaces:block/fluorescent_lamp_on"},
        "lit=false": {"model": "liminalspaces:block/fluorescent_lamp_off"}}}, f, indent=2)
with open(os.path.join(MODEL, "fluorescent_lamp_on.json"), "w") as f:
    json.dump({"parent": "minecraft:block/cube_all",
               "textures": {"all": "liminalspaces:block/fluorescent_lamp_on"}}, f, indent=2)
with open(os.path.join(MODEL, "fluorescent_lamp_off.json"), "w") as f:
    json.dump({"parent": "minecraft:block/cube_all",
               "textures": {"all": "liminalspaces:block/fluorescent_lamp_off"}}, f, indent=2)

# ----------------------------------------------------------------------------
# Loot-таблицы: каждый блок дропает сам себя
# ----------------------------------------------------------------------------
for name in ALL_BLOCKS + ["fluorescent_lamp"]:
    table = {
        "type": "minecraft:block",
        "pools": [{
            "bonus_rolls": 0.0,
            "conditions": [{"condition": "minecraft:survives_explosion"}],
            "entries": [{"type": "minecraft:item", "name": f"liminalspaces:{name}"}],
            "rolls": 1.0
        }]
    }
    with open(os.path.join(LOOT, name + ".json"), "w") as f:
        json.dump(table, f, indent=2)

print(f"OK: {len(TEXTURES)} текстур, {len(ALL_BLOCKS) + 1} blockstates/моделей, "
      f"{len(ALL_BLOCKS) + 1} loot-таблиц")
