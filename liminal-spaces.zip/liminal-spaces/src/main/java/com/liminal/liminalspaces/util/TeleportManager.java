package com.liminal.liminalspaces.util;

import com.liminal.liminalspaces.block.PortalBlock;
import com.liminal.liminalspaces.dimension.LiminalChunkGenerator;
import com.liminal.liminalspaces.registry.ModBlocks;
import com.liminal.liminalspaces.registry.ModDimensions;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraftforge.event.TickEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * Все телепорты выполняются отложенно — в конце серверного тика (ServerTickEvent END),
 * а не из entityInside/обработчиков движения. Эффекты накладываются ПОСЛЕ телепорта.
 */
public class TeleportManager {
    private static final List<Runnable> PENDING = new ArrayList<>();

    public static void queue(ServerPlayer player, PortalBlock.Kind kind, ResourceKey<Level> from) {
        PENDING.add(() -> doTeleport(player, kind, from));
    }

    /** Вызывается из ModEvents в конце серверного тика. */
    public static void flushPending() {
        if (PENDING.isEmpty()) return;
        List<Runnable> copy = new ArrayList<>(PENDING);
        PENDING.clear();
        for (Runnable r : copy) r.run();
    }

    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase == TickEvent.Phase.END) flushPending();
    }

    // ------------------------------------------------------------------

    private static void doTeleport(ServerPlayer player, PortalBlock.Kind kind, ResourceKey<Level> from) {
        if (!ModDimensions.isLiminal(from)) return;
        switch (kind) {
            case WAKE -> wakeUp(player);
            case FORWARD -> {
                ResourceKey<Level> next = ModDimensions.next(from);
                if (next == null) wakeUp(player); else enterDimension(player, next);
            }
            case BACK -> {
                ResourceKey<Level> prev = ModDimensions.previous(from);
                if (prev == null) wakeUp(player); else enterDimension(player, prev);
            }
        }
    }

    /** Вход в измерение через сон (из обработчика сна). */
    public static void enterFirstDimension(ServerPlayer player) {
        enterDimension(player, ModDimensions.PLAYGROUND);
    }

    public static void enterDimension(ServerPlayer player, ResourceKey<Level> dim) {
        safeTeleport(player, dim, 0, 0);
    }

    /** Падение в пустоту: возврат на точку появления без урона. */
    public static void voidToSpawn(ServerPlayer player) {
        ResourceKey<Level> dim = player.level().dimension();
        int[] spawn = getSpawn(player, dim);
        safeTeleport(player, dim, spawn[0], spawn[2]);
    }

    // ------------------------------------------------------------------

    /**
     * Безопасный телепорт: принудительно генерируем чанк, ищем место, где ноги и голова
     * свободны и под ногами твёрдый блок; иначе строим площадку. Сам телепорт — сразу
     * (мы уже в конце тика), эффекты — после телепорта.
     */
    public static void safeTeleport(ServerPlayer player, ResourceKey<Level> dim, int x, int z) {
        ServerLevel level = player.server.getLevel(dim);
        if (level == null) return;

        ChunkAccess chunk = level.getChunk(new ChunkPos(x >> 4, z >> 4)); // форсированная генерация чанка
        int predictedY = LiminalChunkGenerator.surfaceY(dim.location().getPath(), x, z);
        int y = findSafeY(level, chunk, x, z, predictedY);
        if (y < 0) {
            // построить площадку
            for (int dx = -1; dx <= 1; dx++)
                for (int dz = -1; dz <= 1; dz++)
                    level.setBlock(new BlockPos(x + dx, 60, z + dz), ModBlocks.SAFE_PLATFORM.get().defaultBlockState(), 3);
            y = 61;
        }

        player.teleportTo(level, x + 0.5, y, z + 0.5, player.getYRot(), player.getXRot());
        onArrive(player, dim, x, y, z);
    }

    private static int findSafeY(ServerLevel level, ChunkAccess chunk, int x, int z, int predictedY) {
        int lx = x & 15, lz = z & 15;
        for (int dy = 8; dy >= -8; dy--) {
            int y = predictedY + dy;
            if (y < level.getMinBuildHeight() + 2 || y > level.getMaxBuildHeight() - 3) continue;
            BlockState feet = chunk.getBlockState(new BlockPos(lx, y, lz));
            BlockState head = chunk.getBlockState(new BlockPos(lx, y + 1, lz));
            BlockState ground = chunk.getBlockState(new BlockPos(lx, y - 1, lz));
            if (!feet.isAir() || !head.isAir()) continue;
            if (ground.isAir() || !ground.isCollisionShapeFullBlock(level, new BlockPos(x, y - 1, z))) continue;
            return y;
        }
        return -1;
    }

    /** Запоминаем точку появления и при первом визите даём защитные эффекты (после телепорта). */
    private static void onArrive(ServerPlayer player, ResourceKey<Level> dim, int x, int y, int z) {
        CompoundTag data = player.getPersistentData();
        CompoundTag spawns = data.contains("ls_spawns") ? data.getCompound("ls_spawns") : new CompoundTag();
        spawns.putIntArray(dim.location().getPath(), new int[]{x, y, z});
        data.put("ls_spawns", spawns);

        String visitedKey = "ls_visited_" + dim.location().getPath();
        if (!data.getBoolean(visitedKey)) {
            data.putBoolean(visitedKey, true);
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 20 * 30, 3));
            player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 20 * 10, 1));
            player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 20 * 60, 0));
        }
    }

    public static int[] getSpawn(ServerPlayer player, ResourceKey<Level> dim) {
        CompoundTag data = player.getPersistentData();
        if (data.contains("ls_spawns")) {
            CompoundTag spawns = data.getCompound("ls_spawns");
            if (spawns.contains(dim.location().getPath())) {
                return spawns.getIntArray(dim.location().getPath());
            }
        }
        return new int[]{0, LiminalChunkGenerator.surfaceY(dim.location().getPath(), 0, 0) + 1, 0};
    }

    /** Пробуждение: возврат туда, где игрок уснул (записано при засыпании), иначе спавн мира. */
    public static void wakeUp(ServerPlayer player) {
        CompoundTag data = player.getPersistentData();
        if (data.contains("ls_home")) {
            CompoundTag home = data.getCompound("ls_home");
            ResourceKey<Level> dim = ResourceKey.create(net.minecraft.core.registries.Registries.DIMENSION,
                    new net.minecraft.resources.ResourceLocation(home.getString("dim")));
            ServerLevel level = player.server.getLevel(dim);
            if (level != null) {
                double x = home.getDouble("x"), y = home.getDouble("y"), z = home.getDouble("z");
                ChunkAccess chunk = level.getChunk(new ChunkPos(((int) x) >> 4, ((int) z) >> 4));
                int by = findSafeY(level, chunk, (int) x, (int) z, (int) y);
                if (by < 0) by = (int) y;
                player.teleportTo(level, x, by, z, player.getYRot(), player.getXRot());
                return;
            }
        }
        ServerLevel overworld = player.server.getLevel(Level.OVERWORLD);
        BlockPos spawn = overworld.getSharedSpawnPos();
        player.teleportTo(overworld, spawn.getX() + 0.5, spawn.getY() + 1, spawn.getZ() + 0.5,
                player.getYRot(), player.getXRot());
    }
}
