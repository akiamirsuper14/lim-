package com.liminal.liminalspaces.registry;

import com.liminal.liminalspaces.LiminalSpaces;
import com.liminal.liminalspaces.block.FlickeringLampBlock;
import com.liminal.liminalspaces.block.PortalBlock;
import com.liminal.liminalspaces.block.VendingMachineBlock;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, LiminalSpaces.MODID);
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, LiminalSpaces.MODID);

    // ---------- общие / служебные ----------
    public static final RegistryObject<Block> EXIT_SIGN = register("exit_sign",
            () -> new Block(props().strength(1.5f).sound(SoundType.METAL).lightLevel(s -> 15)));
    public static final RegistryObject<Block> PORTAL_FORWARD = register("portal_forward",
            () -> new PortalBlock(PortalBlock.Kind.FORWARD,
                    BlockBehaviour.Properties.of().noCollission().noOcclusion()
                            .strength(-1.0F, 3600000.0F).sound(SoundType.GLASS).lightLevel(s -> 12)));
    public static final RegistryObject<Block> PORTAL_BACK = register("portal_back",
            () -> new PortalBlock(PortalBlock.Kind.BACK,
                    BlockBehaviour.Properties.of().noCollission().noOcclusion()
                            .strength(-1.0F, 3600000.0F).sound(SoundType.GLASS).lightLevel(s -> 12)));
    public static final RegistryObject<Block> PORTAL_WAKE = register("portal_wake",
            () -> new PortalBlock(PortalBlock.Kind.WAKE,
                    BlockBehaviour.Properties.of().noCollission().noOcclusion()
                            .strength(-1.0F, 3600000.0F).sound(SoundType.GLASS).lightLevel(s -> 12)));
    public static final RegistryObject<Block> VENDING_MACHINE = register("vending_machine",
            () -> new VendingMachineBlock(props().strength(2.5f).sound(SoundType.METAL)));
    public static final RegistryObject<Block> CLOUD = register("cloud",
            () -> new Block(props().noCollission().noOcclusion().strength(0.2f)
                    .sound(SoundType.WOOL).lightLevel(s -> 0)));
    public static final RegistryObject<Block> SAFE_PLATFORM = register("safe_platform",
            () -> new Block(props().strength(2.0f).sound(SoundType.STONE)));

    // ---------- измерение 1: площадка ----------
    public static final RegistryObject<Block> DARK_GRASS = register("dark_grass",
            () -> new Block(props().strength(0.6f).sound(SoundType.GRAVEL)));
    public static final RegistryObject<Block> PLAYGROUND_PLATFORM = register("playground_platform",
            () -> new Block(props().strength(0.8f).sound(SoundType.WOOL)));
    public static final RegistryObject<Block> PLAYGROUND_BORDER = register("playground_border",
            () -> new Block(props().strength(0.8f).sound(SoundType.WOOL)));
    public static final RegistryObject<Block> TOWER_RED = register("tower_red",
            () -> new Block(props().strength(1.5f).sound(SoundType.WOOD)));
    public static final RegistryObject<Block> WHITE_POLE = register("white_pole",
            () -> new Block(props().strength(1.5f).sound(SoundType.METAL)));
    public static final RegistryObject<Block> DARK_ROOF = register("dark_roof",
            () -> new Block(props().strength(1.5f).sound(SoundType.WOOD)));
    public static final RegistryObject<Block> BLUE_SLIDE = register("blue_slide",
            () -> new Block(props().strength(1.0f).sound(SoundType.METAL)));
    public static final RegistryObject<Block> SWING_SEAT = register("swing_seat",
            () -> new Block(props().strength(0.8f).sound(SoundType.WOOD)));

    // ---------- измерение 2: коридор ----------
    public static final RegistryObject<Block> BEIGE_WALLPAPER = register("beige_wallpaper",
            () -> new Block(props().strength(1.0f).sound(SoundType.WOOL)));
    public static final RegistryObject<Block> WHITE_TRIM = register("white_trim",
            () -> new Block(props().strength(1.0f).sound(SoundType.WOOD)));
    public static final RegistryObject<Block> BROWN_CARPET = register("brown_carpet",
            () -> new Block(props().strength(0.5f).sound(SoundType.WOOL)));
    public static final RegistryObject<Block> CEILING_TILE = register("ceiling_tile",
            () -> new Block(props().strength(0.8f).sound(SoundType.STONE)));
    public static final RegistryObject<Block> FLUORESCENT_LAMP = register("fluorescent_lamp",
            () -> new FlickeringLampBlock(props().sound(SoundType.GLASS)));
    public static final RegistryObject<Block> ROOM_DOOR = register("room_door",
            () -> new Block(props().strength(1.2f).sound(SoundType.WOOD)));

    // ---------- измерение 3: дорога ----------
    public static final RegistryObject<Block> ASPHALT = register("asphalt",
            () -> new Block(props().strength(1.5f).sound(SoundType.STONE)));
    public static final RegistryObject<Block> ROAD_LINE = register("road_line",
            () -> new Block(props().strength(1.5f).sound(SoundType.STONE).lightLevel(s -> 2)));
    public static final RegistryObject<Block> STOP_SIGN = register("stop_sign",
            () -> new Block(props().strength(1.0f).noOcclusion().lightLevel(s -> 6)));
    public static final RegistryObject<Block> METAL_POLE = register("metal_pole",
            () -> new Block(props().strength(1.5f).sound(SoundType.METAL)));

    // ---------- измерение 4: самолёт ----------
    public static final RegistryObject<Block> CABIN_WALL = register("cabin_wall",
            () -> new Block(props().strength(1.2f).sound(SoundType.METAL)));
    public static final RegistryObject<Block> CABIN_FLOOR = register("cabin_floor",
            () -> new Block(props().strength(1.0f).sound(SoundType.WOOL)));
    public static final RegistryObject<Block> CABIN_CEILING = register("cabin_ceiling",
            () -> new Block(props().strength(1.0f).sound(SoundType.METAL)));
    public static final RegistryObject<Block> AIRPLANE_WINDOW = register("airplane_window",
            () -> new Block(BlockBehaviour.Properties.of().noOcclusion().strength(0.5f)
                    .sound(SoundType.GLASS).lightLevel(s -> 8)));
    public static final RegistryObject<Block> AIRPLANE_SEAT = register("airplane_seat",
            () -> new Block(props().strength(0.8f).sound(SoundType.WOOL)));
    public static final RegistryObject<Block> BLUE_LIGHT_STRIP = register("blue_light_strip",
            () -> new Block(props().strength(0.5f).sound(SoundType.GLASS).lightLevel(s -> 14)));
    public static final RegistryObject<Block> OVERHEAD_HANDLE = register("overhead_handle",
            () -> new Block(props().strength(0.4f).noOcclusion().sound(SoundType.METAL)));

    // ---------- измерение 5: луг ----------
    public static final RegistryObject<Block> PATH_DIRT = register("path_dirt",
            () -> new Block(props().strength(0.6f).sound(SoundType.GRAVEL)));
    public static final RegistryObject<Block> IVY_HOUSE = register("ivy_house",
            () -> new Block(props().strength(2.0f).sound(SoundType.STONE)));
    public static final RegistryObject<Block> DARK_DOORWAY = register("dark_doorway",
            () -> new Block(props().strength(50.0f).sound(SoundType.STONE).lightLevel(s -> 0)));

    // ---------- helpers ----------
    private static BlockBehaviour.Properties props() {
        return BlockBehaviour.Properties.of(); // 1.20.1: без Material
    }

    private static RegistryObject<Block> register(String name, java.util.function.Supplier<Block> supplier) {
        RegistryObject<Block> block = BLOCKS.register(name, supplier);
        ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
        return block;
    }

    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
        ITEMS.register(bus);
    }
}
