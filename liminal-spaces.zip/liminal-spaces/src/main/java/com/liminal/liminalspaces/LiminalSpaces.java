package com.liminal.liminalspaces;

import com.liminal.liminalspaces.event.ModEvents;
import com.liminal.liminalspaces.registry.ModBlockEntities;
import com.liminal.liminalspaces.registry.ModBlocks;
import com.liminal.liminalspaces.registry.ModCreativeTab;
import com.liminal.liminalspaces.setup.ModCommonSetup;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(LiminalSpaces.MODID)
public class LiminalSpaces {
    public static final String MODID = "liminalspaces";

    public LiminalSpaces() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.register(bus);
        ModBlockEntities.register(bus);
        ModCreativeTab.register(bus);
        ModEvents.register();
        bus.addListener(ModCommonSetup::onCommonSetup);
    }
}
