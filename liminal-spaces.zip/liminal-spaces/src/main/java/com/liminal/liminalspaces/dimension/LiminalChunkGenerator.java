package com.liminal.liminalspaces.dimension;

import com.liminal.liminalspaces.block.FlickeringLampBlock;
import com.liminal.liminalspaces.registry.ModBlocks;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.Registry;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.levelgen.blending.Blender;

import java.util.concurrent.Executor;

/**
 * Кастомный генератор: геометрия каждого чанка — чистая функция мировых координат
 * (хеши + value-noise), без хранения состояния. Каждый чанк самодостаточен,
 * структуры, пересекающие границу, обрезаются по границам чанка.
 *
 * Сигнатуры под 1.20.1 (official mappings).
 */
public class LiminalChunkGenerator extends ChunkGenerator {
    public static final Codec<LiminalChunkGenerator> CODEC = RecordCodecBuilder.create(inst -> inst.group(
            BiomeSource.CODEC.fieldOf("biome_source").forGetter(g -> g.biomeSource),
            Codec.STRING.fieldOf("dimension").forGetter(g -> g.dimension)
    ).apply(inst, LiminalChunkGenerator::new));

    private final String dimension;

    public LiminalChunkGenerator(BiomeSource biomeSource, String dimension) {
        super(biomeSource);
        this.dimension = dimension;
    }

    @Override
    protected Codec<? extends ChunkGenerator> codec() {
        return CODEC;
    }

    @Override
    public void createBiomes(Registry<Biome> biomeRegistry, Executor executor, RandomState randomState,
                             StructureManager structureManager) {
        // биомы приходят из data-файлов (worldgen/biome), здесь ничего не делаем
    }

    @Override
    public void fillFromNoise(Executor executor, Blender blender, RandomState randomState,
                              StructureManager structureManager, ChunkAccess chunk) {
        // пустое "шумовое" основание: всю геометрию рисуем в buildSurface
    }

    @Override
    public void buildSurface(WorldGenRegion region, StructureManager structureManager,
                             RandomState randomState, ChunkAccess chunk) {
        ChunkPos pos = chunk.getPos();
        int baseX = pos.getMinBlockX();
        int baseZ = pos.getMinBlockZ();
        switch (dimension) {
            case "playground" -> genPlayground(chunk, baseX, baseZ);
            case "hallway" -> genHallway(chunk, baseX, baseZ);
            case "desert_road" -> genDesertRoad(chunk, baseX, baseZ);
            case "airplane" -> genAirplane(chunk, baseX, baseZ);
            case "meadow" -> genMeadow(chunk, baseX, baseZ);
        }
    }

    @Override
    public int getBaseHeight(int x, int z, Heightmap.Types type, LevelHeightAccessor level, RandomState random) {
        return surfaceY(dimension, x, z);
    }

    @Override
    public NoiseColumn getBaseColumn(int x, int z, LevelHeightAccessor level, RandomState random) {
        return new NoiseColumn(level.getMinBuildHeight(), new BlockState[0]);
    }

    @Override
    public void spawnOriginalMobs(WorldGenRegion region) {
        // мобов нет (животные задаются только в биоме meadow через data-файл)
    }

    // ==================================================================
    //  "Предсказанная" высота поверхности — та же функция, что и в генераторе,
    //  нужна для безопасного телепорта.
    // ==================================================================
    public static int surfaceY(String dim, int x, int z) {
        return switch (dim) {
            case "playground" -> 60;
            case "hallway" -> 64;
            case "desert_road" -> 60 + mesaHeight(x, z);
            case "airplane" -> 60;
            case "meadow" -> 60 + meadowHeight(x, z);
            default -> 64;
        };
    }

    // ==================================================================
    //  Хеши и value-noise (детерминированные, без состояния)
    // ==================================================================
    private static long mix(long h) {
        h ^= h >>> 33; h *= 0xff51afd7ed558ccdL;
        h ^= h >>> 33; h *= 0xc4ceb9fe1a85ec53L;
        h ^= h >>> 33;
        return h;
    }

    private static double hash01(int x, int z, int salt) {
        long h = mix((long) x * 0x9E3779B1L + (long) z * 0x85EBCA77L + (long) salt * 0xC2B2AE3DL + 0x27D4EB2FL);
        return (h >>> 11) * (1.0 / 9007199254740992.0);
    }

    private static double smooth(double t) { return t * t * (3 - 2 * t); }

    private static double valueNoise(int x, int z, int scale, int salt) {
        int gx = Math.floorDiv(x, scale), gz = Math.floorDiv(z, scale);
        double fx = (x - gx * scale) / (double) scale, fz = (z - gz * scale) / (double) scale;
        double a = hash01(gx, gz, salt), b = hash01(gx + 1, gz, salt);
        double c = hash01(gx, gz + 1, salt), d = hash01(gx + 1, gz + 1, salt);
        double u = smooth(fx), v = smooth(fz);
        return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
    }

    private static double fbm(int x, int z, int salt) {
        return valueNoise(x, z, 64, salt) * 0.6 + valueNoise(x, z, 24, salt + 1) * 0.3
                + valueNoise(x, z, 8, salt + 2) * 0.1;
    }

    private static int meadowHeight(int x, int z) {
        return (int) Math.round(fbm(x, z, 11) * 7.0);
    }

    private static int mesaHeight(int x, int z) {
        double h = fbm(x, z, 31);
        if (h < 0.60) return 0;
        return (int) Math.round((h - 0.60) * 90.0);
    }

    // ==================================================================
    //  Утилиты размещения
    // ==================================================================
    private static void set(ChunkAccess c, int wx, int y, int wz, BlockState state) {
        c.setBlockState(new BlockPos(wx & 15, y, wz & 15), state, false);
    }

    private static void setLocal(ChunkAccess c, int lx, int y, int lz, BlockState state) {
        if (lx < 0 || lx > 15 || lz < 0 || lz > 15) return; // обрезка по границе чанка
        c.setBlockState(new BlockPos(lx, y, lz), state, false);
    }

    private static void fillBox(ChunkAccess c, int x0, int x1, int y0, int y1, int z0, int z1, BlockState s) {
        for (int x = x0; x <= x1; x++)
            for (int y = y0; y <= y1; y++)
                for (int z = z0; z <= z1; z++)
                    set(c, x, y, z, s);
    }

    private static final BlockState LAMP_LIT = ModBlocks.FLUORESCENT_LAMP.get().defaultBlockState()
            .setValue(FlickeringLampBlock.LIT, true);
    private static final BlockState LAMP_DIM = ModBlocks.FLUORESCENT_LAMP.get().defaultBlockState()
            .setValue(FlickeringLampBlock.LIT, false);

    // ==================================================================
    //  Врата (вперёд/назад) + табличка EXIT — ставятся в чанке, содержащем (0,0)
    // ==================================================================
    private void placePortals(ChunkAccess chunk, int baseX, int baseZ, String dim, int groundY) {
        // назад — рядом со спауном (2, ?, 0), вперёд — в (-8, ?, 0) с табличкой EXIT
        int[][] back = {{2, 0}, {3, 0}};
        int[][] fwd = {{-8, 0}, {-8, 1}};
        BlockState backBlock, fwdBlock;
        switch (dim) {
            case "playground" -> { backBlock = ModBlocks.PORTAL_WAKE.get().defaultBlockState();
                                   fwdBlock = ModBlocks.PORTAL_FORWARD.get().defaultBlockState(); }
            case "meadow" -> { backBlock = ModBlocks.PORTAL_BACK.get().defaultBlockState();
                               fwdBlock = ModBlocks.PORTAL_WAKE.get().defaultBlockState(); }
            default -> { backBlock = ModBlocks.PORTAL_BACK.get().defaultBlockState();
                         fwdBlock = ModBlocks.PORTAL_FORWARD.get().defaultBlockState(); }
        }
        for (int[] p : back) placePortalAt(chunk, baseX, baseZ, p[0], groundY + 1, p[1], backBlock);
        for (int[] p : fwd) placePortalAt(chunk, baseX, baseZ, p[0], groundY + 1, p[1], fwdBlock);
        placePortalAt(chunk, baseX, baseZ, -7, groundY + 1, 0, ModBlocks.EXIT_SIGN.get().defaultBlockState());
    }

    private static void placePortalAt(ChunkAccess c, int baseX, int baseZ, int wx, int y, int wz, BlockState s) {
        int lx = wx - baseX, lz = wz - baseZ;
        if (lx < 0 || lx > 15 || lz < 0 || lz > 15) return;
        setLocal(c, lx, y, lz, s);
        setLocal(c, lx, y + 1, lz, s); // врата высотой в 2 блока
    }

    // ==================================================================
    //  ИЗМЕРЕНИЕ 1 — ночная детская площадка
    // ==================================================================
    private void genPlayground(ChunkAccess c, int baseX, int baseZ) {
        // бесконечное тёмное поле
        for (int lx = 0; lx < 16; lx++)
            for (int lz = 0; lz < 16; lz++) {
                int wx = baseX + lx, wz = baseZ + lz;
                setLocal(c, lx, 60, lz, ModBlocks.DARK_GRASS.get().defaultBlockState());
                setLocal(c, lx, 59, lz, Blocks.DIRT.defaultBlockState());
                setLocal(c, lx, 58, lz, Blocks.DIRT.defaultBlockState());
            }
        // площадки повторяются каждые 96 блоков (детерминированно)
        int cellX0 = Math.floorDiv(baseX, 96), cellX1 = Math.floorDiv(baseX + 15, 96);
        int cellZ0 = Math.floorDiv(baseZ, 96), cellZ1 = Math.floorDiv(baseZ + 15, 96);
        for (int cx = cellX0; cx <= cellX1; cx++)
            for (int cz = cellZ0; cz <= cellZ1; cz++) {
                if (hash01(cx, cz, 101) > 0.75) continue; // не в каждой клетке
                int ox = cx * 96 + 48, oz = cz * 96 + 48;
                buildPlayground(c, baseX, baseZ, ox, oz);
            }
        placePortals(c, baseX, baseZ, "playground", 60);
        // кусты сладких ягод
        scatterSweetBerries(c, baseX, baseZ, 55);
    }

    private void buildPlayground(ChunkAccess c, int baseX, int baseZ, int ox, int oz) {
        // круглая оранжевая площадка радиусом 6 с фиолетовым бордюром
        for (int dx = -7; dx <= 7; dx++)
            for (int dz = -7; dz <= 7; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > 6.5) continue;
                BlockState s = d > 5.5 ? ModBlocks.PLAYGROUND_BORDER.get().defaultBlockState()
                        : ModBlocks.PLAYGROUND_PLATFORM.get().defaultBlockState();
                set(c, ox + dx, 61, oz + dz, s);
            }
        // красная башня 3x3, белые столбы по углам, тёмная крыша
        for (int dx = -1; dx <= 1; dx++)
            for (int dz = -1; dz <= 1; dz++)
                for (int y = 62; y <= 65; y++)
                    set(c, ox + dx, y, oz + dz, ModBlocks.TOWER_RED.get().defaultBlockState());
        int[][] corners = {{-2, -2}, {2, -2}, {-2, 2}, {2, 2}};
        for (int[] p : corners)
            for (int y = 62; y <= 67; y++)
                set(c, ox + p[0], y, oz + p[1], ModBlocks.WHITE_POLE.get().defaultBlockState());
        for (int dx = -3; dx <= 3; dx++)
            for (int dz = -3; dz <= 3; dz++)
                if (Math.abs(dx) + Math.abs(dz) <= 4)
                    set(c, ox + dx, 68, oz + dz, ModBlocks.DARK_ROOF.get().defaultBlockState());
        // синяя горка от башни
        for (int i = 0; i <= 5; i++)
            set(c, ox + 2 + i, 65 - i / 2, oz, ModBlocks.BLUE_SLIDE.get().defaultBlockState());
        // качели: две стойки + перекладина + сиденье
        for (int y = 62; y <= 65; y++) {
            set(c, ox - 4, y, oz + 4, ModBlocks.WHITE_POLE.get().defaultBlockState());
            set(c, ox - 4, y, oz + 7, ModBlocks.WHITE_POLE.get().defaultBlockState());
        }
        set(c, ox - 4, 65, oz + 5, ModBlocks.WHITE_POLE.get().defaultBlockState());
        set(c, ox - 4, 65, oz + 6, ModBlocks.WHITE_POLE.get().defaultBlockState());
        set(c, ox - 4, 63, oz + 5, ModBlocks.SWING_SEAT.get().defaultBlockState());
        set(c, ox - 4, 63, oz + 6, ModBlocks.SWING_SEAT.get().defaultBlockState());
    }

    // ==================================================================
    //  ИЗМЕРЕНИЕ 2 — бесконечный коридор (вдоль Z, стены по X=±3)
    // ==================================================================
    private void genHallway(ChunkAccess c, int baseX, int baseZ) {
        for (int lx = 0; lx < 16; lx++) {
            int wx = baseX + lx;
            for (int lz = 0; lz < 16; lz++) {
                int wz = baseZ + lz;
                boolean doorZ = Math.floorMod(wz, 8) == 4;
                for (int y = 60; y <= 70; y++) {
                    BlockState s;
                    if (wx >= -2 && wx <= 2) {
                        // пол коридора
                        if (y == 64) s = ModBlocks.BROWN_CARPET.get().defaultBlockState();
                        else if (y == 68) s = (Math.floorMod(wz, 6) == 0 && wx == 0)
                                ? (hash01(wx, wz, 202) < 0.12 ? LAMP_DIM : LAMP_LIT) // изредка мерцают/выкл
                                : ModBlocks.CEILING_TILE.get().defaultBlockState();
                        else s = null; // воздух
                    } else if (Math.abs(wx) == 3) {
                        // стена с дверями
                        if (doorZ && y >= 65 && y <= 67) s = ModBlocks.ROOM_DOOR.get().defaultBlockState();
                        else if (y == 64 || y == 68) s = ModBlocks.WHITE_TRIM.get().defaultBlockState(); // плинтус
                        else s = ModBlocks.BEIGE_WALLPAPER.get().defaultBlockState();
                        // наличники вокруг двери
                        if (!doorZ && Math.floorMod(wz, 8) == 3 && y >= 65 && y <= 67 && Math.abs(wx) == 3)
                            s = ModBlocks.WHITE_TRIM.get().defaultBlockState();
                    } else if (Math.abs(wx) >= 4 && Math.abs(wx) <= 10 && doorZ
                            && Math.abs(Math.floorMod(wz - 4, 8)) <= 3 && y >= 64 && y <= 68) {
                        // комната за дверью
                        int roomLocal = Math.floorMod(wz, 8);
                        if (y == 64) s = ModBlocks.BROWN_CARPET.get().defaultBlockState();
                        else if (y == 68) s = ModBlocks.CEILING_TILE.get().defaultBlockState();
                        else if (Math.abs(wx) == 4 || Math.abs(wx) == 10 || roomLocal == 0 || roomLocal == 7 || roomLocal == 8 - 1)
                            s = ModBlocks.BEIGE_WALLPAPER.get().defaultBlockState();
                        else {
                            // случайный декор комнаты (детерминированно)
                            double r = hash01(wx, wz, 303);
                            if (y == 66 && r < 0.10) s = hash01(wx, wz, 304) < 0.5 ? LAMP_LIT : LAMP_DIM;
                            else if (y == 65 && r > 0.85) s = Blocks.BOOKSHELF.defaultBlockState();
                            else s = null;
                        }
                    } else {
                        s = ModBlocks.BEIGE_WALLPAPER.get().defaultBlockState(); // "сплошь" за коридором
                    }
                    if (s != null) setLocal(c, lx, y, lz, s);
                }
            }
        }
        placePortals(c, baseX, baseZ, "hallway", 64);
        scatterSweetBerries(c, baseX, baseZ, 57);
    }

    // ==================================================================
    //  ИЗМЕРЕНИЕ 3 — дорога в красной пустыне
    // ==================================================================
    private void genDesertRoad(ChunkAccess c, int baseX, int baseZ) {
        for (int lx = 0; lx < 16; lx++)
            for (int lz = 0; lz < 16; lz++) {
                int wx = baseX + lx, wz = baseZ + lz;
                int mh = mesaHeight(wx, wz);
                boolean roadX = Math.abs(wz) <= 3;                       // дорога вдоль X
                boolean roadZ = Math.floorMod(wx, 64) >= 30 && Math.floorMod(wx, 64) <= 36; // перекрёстки вдоль Z
                if (roadX || roadZ) {
                    setLocal(c, lx, 60, lz, ModBlocks.ASPHALT.get().defaultBlockState());
                    // разметка: центральная прерывистая линия
                    if (!roadZ && wz == 0 && Math.floorMod(wx, 4) < 2)
                        setLocal(c, lx, 60, lz, ModBlocks.ROAD_LINE.get().defaultBlockState());
                    if (roadX && !roadZ && Math.abs(wz) == 3)
                        setLocal(c, lx, 60, lz, ModBlocks.ROAD_LINE.get().defaultBlockState()); // край
                } else {
                    for (int y = 60; y <= 60 + mh; y++)
                        setLocal(c, lx, y, lz, y == 60 + mh ? Blocks.RED_SAND.defaultBlockState()
                                : Blocks.RED_SANDSTONE.defaultBlockState());
                }
                // знаки STOP на углах перекрёстков
                if (Math.floorMod(wx, 64) == 30 && Math.floorMod(wz, 64) == 30) {
                    set(c, wx, 61, wz, ModBlocks.METAL_POLE.get().defaultBlockState());
                    set(c, wx, 62, wz, ModBlocks.METAL_POLE.get().defaultBlockState());
                    set(c, wx, 63, wz, ModBlocks.METAL_POLE.get().defaultBlockState());
                    set(c, wx, 64, wz, ModBlocks.STOP_SIGN.get().defaultBlockState());
                }
            }
        // котлы с водой у перекрёстков + руды в подземном слое
        if (Math.floorMod(baseX, 64) == 0 && Math.floorMod(baseZ, 64) == 0) {
            set(c, 32, 61, 32, Blocks.CAULDRON.defaultBlockState());
        }
        scatterOres(c, baseX, baseZ);
        placePortals(c, baseX, baseZ, "desert_road", 60);
        scatterSweetBerries(c, baseX, baseZ, 58);
    }

    // ==================================================================
    //  ИЗМЕРЕНИЕ 4 — кабина самолёта в небе
    // ==================================================================
    private void genAirplane(ChunkAccess c, int baseX, int baseZ) {
        for (int lx = 0; lx < 16; lx++) {
            int wx = baseX + lx;
            for (int lz = 0; lz < 16; lz++) {
                int wz = baseZ + lz;
                boolean window = Math.floorMod(wz, 2) == 0;
                for (int y = 56; y <= 72; y++) {
                    BlockState s = null;
                    if (wx >= -2 && wx <= 2) {
                        if (y == 60) s = ModBlocks.CABIN_FLOOR.get().defaultBlockState();
                        else if (y == 66) s = ModBlocks.CABIN_CEILING.get().defaultBlockState();
                        if (y == 66 && Math.floorMod(wz, 4) == 0 && wx == 0)
                            s = ModBlocks.BLUE_LIGHT_STRIP.get().defaultBlockState(); // синие полосы на потолке
                        if (y == 65 && Math.floorMod(wz, 3) == 0 && wx == 0)
                            s = ModBlocks.OVERHEAD_HANDLE.get().defaultBlockState(); // поручни
                        if (y >= 61 && y <= 63 && wx == 1 && Math.floorMod(wz, 2) == 0)
                            s = ModBlocks.AIRPLANE_SEAT.get().defaultBlockState(); // ряд сидений у окон
                        if (s == null && y >= 61 && y <= 65) s = null; // воздух кабины
                    } else if (Math.abs(wx) == 3) {
                        if (window && y >= 62 && y <= 64) s = ModBlocks.AIRPLANE_WINDOW.get().defaultBlockState();
                        else if (y == 60) s = ModBlocks.CABIN_FLOOR.get().defaultBlockState();
                        else if (y == 66) s = ModBlocks.CABIN_CEILING.get().defaultBlockState();
                        else s = ModBlocks.CABIN_WALL.get().defaultBlockState();
                    } else {
                        // облака снаружи и снизу
                        if (y <= 59 || (y <= 70 && hash01(wx * 7 + y, wz * 13, 404) < 0.55))
                            s = ModBlocks.CLOUD.get().defaultBlockState();
                    }
                    if (s != null) setLocal(c, lx, y, lz, s);
                }
            }
        }
        placePortals(c, baseX, baseZ, "airplane", 60);
        scatterSweetBerries(c, baseX, baseZ, 56);
    }

    // ==================================================================
    //  ИЗМЕРЕНИЕ 5 — травяное поле, тропа к плющом обросшей постройке
    // ==================================================================
    private void genMeadow(ChunkAccess c, int baseX, int baseZ) {
        for (int lx = 0; lx < 16; lx++)
            for (int lz = 0; lz < 16; lz++) {
                int wx = baseX + lx, wz = baseZ + lz;
                int h = meadowHeight(wx, wz);
                int top = 60 + h;
                for (int y = top - 3; y <= top; y++)
                    setLocal(c, lx, y, lz, y == top ? Blocks.GRASS_BLOCK.defaultBlockState() : Blocks.DIRT.defaultBlockState());
                // извилистая тропа: кривая, проходящая через (0,0) к постройке
                int curve = (int) Math.round(25.0 * Math.sin(wx * 0.08) + 8.0 * Math.sin(wx * 0.031));
                if (Math.abs(wz - curve) <= 1 && Math.abs(wx) <= 220)
                    setLocal(c, lx, top, lz, ModBlocks.PATH_DIRT.get().defaultBlockState());
                // пруд
                if (hash01(Math.floorDiv(wx, 24), Math.floorDiv(wz, 24), 505) < 0.06
                        && Math.abs(wx) > 30 && Math.abs(wz) > 30) {
                    setLocal(c, lx, top, lz, Blocks.WATER.defaultBlockState());
                }
            }
        // постройка в клетке (0,0): домик 5x5, обросший плющом, с тёмным проёмом
        buildIvyHouse(c, baseX, baseZ);
        // руды в подземном слое
        scatterOres(c, baseX, baseZ);
        placePortals(c, baseX, baseZ, "meadow", surfaceY("meadow", 0, 0));
        scatterSweetBerries(c, baseX, baseZ, 59);
    }

    private void buildIvyHouse(ChunkAccess c, int baseX, int baseZ) {
        int top0 = surfaceY("meadow", 0, 0);
        // стены из блока "дом, обросший плющом" (текстура уже с плющом);
        // состояния задаются явно, т.к. при генерации чанка нет обновлений соседей
        for (int dx = -2; dx <= 2; dx++)
            for (int dz = -2; dz <= 2; dz++)
                for (int y = top0 + 1; y <= top0 + 4; y++)
                    if (Math.abs(dx) == 2 || Math.abs(dz) == 2)
                        set(c, dx, y, dz, ModBlocks.IVY_HOUSE.get().defaultBlockState());
        // тёмный проём на южной стороне
        set(c, 0, top0 + 1, -2, ModBlocks.DARK_DOORWAY.get().defaultBlockState());
        set(c, 0, top0 + 2, -2, ModBlocks.DARK_DOORWAY.get().defaultBlockState());
        // крыша
        for (int dx = -3; dx <= 3; dx++)
            for (int dz = -3; dz <= 3; dz++)
                set(c, dx, top0 + 5, dz, Blocks.OAK_PLANKS.defaultBlockState());
        // огромное облако над постройкой
        for (int dx = -3; dx <= 3; dx++)
            for (int dz = -3; dz <= 3; dz++)
                for (int dy = 0; dy < 2; dy++)
                    if (Math.abs(dx) + Math.abs(dz) + dy <= 5)
                        set(c, dx, top0 + 16 + dy, dz, ModBlocks.CLOUD.get().defaultBlockState());
    }

    // ==================================================================
    //  Общие вкрапления: ягоды, руды
    // ==================================================================
    private void scatterSweetBerries(ChunkAccess c, int baseX, int baseZ, int salt) {
        for (int lx = 0; lx < 16; lx++)
            for (int lz = 0; lz < 16; lz++) {
                int wx = baseX + lx, wz = baseZ + lz;
                if (hash01(wx, wz, salt) < 0.02) {
                    int y = surfaceY(dimension, wx, wz) + 1;
                    setLocal(c, lx, y, lz, Blocks.SWEET_BERRY_BUSH.defaultBlockState());
                }
            }
    }

    private void scatterOres(ChunkAccess c, int baseX, int baseZ) {
        for (int lx = 0; lx < 16; lx++)
            for (int lz = 0; lz < 16; lz++) {
                int wx = baseX + lx, wz = baseZ + lz;
                for (int y = 8; y <= 40; y += 4) {
                    double r = hash01(wx, wz * 31 + y, 606);
                    if (r < 0.012) setLocal(c, lx, y, lz, Blocks.COAL_ORE.defaultBlockState());
                    else if (r < 0.018) setLocal(c, lx, y, lz, Blocks.IRON_ORE.defaultBlockState());
                    else if (r < 0.021) setLocal(c, lx, y, lz, Blocks.GOLD_ORE.defaultBlockState());
                }
            }
    }
}
