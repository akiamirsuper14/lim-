package com.liminal.liminalspaces.event;

import com.liminal.liminalspaces.registry.ModDimensions;
import com.liminal.liminalspaces.util.TeleportManager;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BedBlock;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.entity.player.PlayerSleepInBedEvent;
import net.minecraftforge.event.entity.player.PlayerWokeUpEvent;
import net.minecraftforge.eventbus.api.Event;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Сон → вход в измерения; кровать в измерениях взрывается; падение в пустоту;
 * отмена урона от падения в измерении самолёта; обработка отложенных телепортов.
 */
public class ModEvents {
    private static final Map<UUID, Long> SLEEP_START = new HashMap<>();
    private static final double ENTER_CHANCE = 0.25;
    private static final long MIN_SLEEP_TICKS = 100;

    public static void register() {
        MinecraftForge.EVENT_BUS.addListener(ModEvents::onSleepStart);
        MinecraftForge.EVENT_BUS.addListener(ModEvents::onWokeUp);
        MinecraftForge.EVENT_BUS.addListener(ModEvents::onRightClickBlock);
        MinecraftForge.EVENT_BUS.addListener(ModEvents::onPlayerTick);
        MinecraftForge.EVENT_BUS.addListener(ModEvents::onFall);
        MinecraftForge.EVENT_BUS.addListener(TeleportManager::onServerTick);
    }

    /** Запоминаем момент засыпания и точку "дома" (куда вернуться после пробуждения). */
    private static void onSleepStart(PlayerSleepInBedEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            SLEEP_START.put(player.getUUID(), player.level().getGameTime());
            CompoundTag home = new CompoundTag();
            home.putString("dim", player.level().dimension().location().toString());
            home.putDouble("x", player.getX());
            home.putDouble("y", player.getY());
            home.putDouble("z", player.getZ());
            player.getPersistentData().put("ls_home", home);
        }
    }

    /** Пробуждение после настоящего сна: ≥100 тиков и шанс 25% → измерение 1. */
    private static void onWokeUp(PlayerWokeUpEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (ModDimensions.isLiminal(player.level().dimension())) return; // внутри измерений не спим
        Long start = SLEEP_START.remove(player.getUUID());
        if (start == null) return;
        long slept = player.level().getGameTime() - start;
        if (slept >= MIN_SLEEP_TICKS && player.getRandom().nextDouble() < ENTER_CHANCE) {
            TeleportManager.enterFirstDimension(player);
        }
    }

    /** В измерениях кровать не работает — клик по ней вызывает взрыв. */
    private static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        Level level = event.getLevel();
        if (!ModDimensions.isLiminal(level.dimension())) return;
        if (!(level.getBlockState(event.getPos()).getBlock() instanceof BedBlock)) return;
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.FAIL);
        if (!level.isClientSide) {
            BlockPos pos = event.getPos();
            level.removeBlock(pos, false);
            level.explode(event.getEntity(), pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                    1.5f, Level.ExplosionInteraction.BLOCK);
        }
    }

    /** Падение в пустоту (y < 4) → на точку появления без урона. */
    private static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.player instanceof ServerPlayer player)) return;
        if (!ModDimensions.isLiminal(player.level().dimension())) return;
        if (player.getY() < 4 && !player.isDeadOrDying()) {
            TeleportManager.voidToSpawn(player);
        }
    }

    /** Облака в измерении самолёта не наносят урон от падения. */
    private static void onFall(LivingFallEvent event) {
        if (event.getEntity() instanceof ServerPlayer player
                && player.level().dimension() == ModDimensions.AIRPLANE) {
            event.setDamageMultiplier(0.0f);
            event.setCanceled(true);
        }
    }
}
