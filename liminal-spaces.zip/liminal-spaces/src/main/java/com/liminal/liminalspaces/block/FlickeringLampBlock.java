package com.liminal.liminalspaces.block;

import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;

/**
 * Люминесцентная панель. Иногда мерцает (случайный тик переключает LIT).
 * При генерации мира состояние LIT задаётся явно генератором — без обновлений соседей.
 */
public class FlickeringLampBlock extends Block {
    public static final BooleanProperty LIT = BlockStateProperties.LIT;

    public FlickeringLampBlock(Properties properties) {
        super(properties.randomTicks());
        registerDefaultState(stateDefinition.any().setValue(LIT, true));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(LIT);
    }

    @Override
    public void randomTick(BlockState state, net.minecraft.server.level.ServerLevel level,
                           BlockPos pos, RandomSource random) {
        if (random.nextInt(100) < 5) { // ~5% шанс мерцания за тик
            level.setBlock(pos, state.setValue(LIT, !state.getValue(LIT)), 3);
        }
    }

    @Override
    public int getLightEmission(BlockState state, BlockGetter level, BlockPos pos) {
        return state.getValue(LIT) ? 15 : 3;
    }
}
