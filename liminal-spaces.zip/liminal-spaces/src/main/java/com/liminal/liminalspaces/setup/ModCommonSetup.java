package com.liminal.liminalspaces.setup;

import com.liminal.liminalspaces.LiminalSpaces;
import com.liminal.liminalspaces.dimension.LiminalChunkGenerator;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;

public class ModCommonSetup {
    public static void onCommonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(() -> Registry.register(
                BuiltInRegistries.CHUNK_GENERATOR,
                new ResourceLocation(LiminalSpaces.MODID, "liminal"),
                LiminalChunkGenerator.CODEC));
    }
}
