package com.liminal.liminalspaces.block;

import com.liminal.liminalspaces.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import java.util.Random;

public class VendingMachineBlockEntity extends BlockEntity {
    public static final int MAX_STOCK = 12;
    public static final long REFILL_TICKS = 20L * 60 * 5; // пополнение каждые 5 минут

    private int stock = MAX_STOCK;
    private long nextRefill = 0;
    private final Random random = new Random();

    public VendingMachineBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.VENDING_MACHINE.get(), pos, state);
    }

    @Nullable
    public ItemStack dispense(java.util.Random rand) {
        if (stock <= 0) return null;
        stock--;
        if (stock == 0) nextRefill = (level != null ? level.getGameTime() : 0) + REFILL_TICKS;
        return VendingMachineBlock.randomSnack(rand);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, VendingMachineBlockEntity be) {
        if (be.stock <= 0 && level.getGameTime() >= be.nextRefill) {
            be.stock = MAX_STOCK;
            be.setChanged();
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("Stock", stock);
        tag.putLong("NextRefill", nextRefill);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        stock = tag.getInt("Stock");
        nextRefill = tag.getLong("NextRefill");
    }
}
