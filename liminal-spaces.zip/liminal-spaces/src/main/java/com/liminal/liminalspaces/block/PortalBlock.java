package com.liminal.liminalspaces.block;

import com.liminal.liminalspaces.util.TeleportManager;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Полупрозрачные неразрушимые врата. Срабатывают при входе игрока в блок.
 * Сам телепорт всегда откладывается до конца серверного тика (см. TeleportManager).
 */
public class PortalBlock extends Block {
    public enum Kind { FORWARD, BACK, WAKE }

    private final Kind kind;

    public PortalBlock(Kind kind, Properties properties) {
        super(properties);
        this.kind = kind;
    }

    public Kind getKind() {
        return kind;
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (!level.isClientSide && entity instanceof ServerPlayer player && entity.tickCount % 5 == 0) {
            TeleportManager.queue(player, kind, level.dimension());
        }
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.block();
    }
}
