package com.liminal.liminalspaces.block;

import com.liminal.liminalspaces.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionUtils;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.registries.RegistryObject;

import javax.annotation.Nullable;

/**
 * Торговый автомат: правый клик выдаёт воду/еду, пока есть запас.
 * Когда пустеет — пополняется со временем (тикер BlockEntity).
 */
public class VendingMachineBlock extends BaseEntityBlock {
    public VendingMachineBlock(Properties properties) {
        super(properties);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new VendingMachineBlockEntity(pos, state);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos,
                                            Player player, BlockHitResult hit) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof VendingMachineBlockEntity vm) {
            ItemStack given = vm.dispense(level.getRandom());
            if (given != null && !player.getInventory().add(given)) {
                player.drop(given, false);
            }
            if (given != null) {
                level.playSound(null, pos, SoundEvents.DISPENSER_DISPENSE, SoundSource.BLOCKS, 1.0f, 1.2f);
                return InteractionResult.SUCCESS;
            } else {
                level.playSound(null, pos, SoundEvents.DISPENSER_FAIL, SoundSource.BLOCKS, 1.0f, 1.0f);
                return InteractionResult.CONSUME;
            }
        }
        return InteractionResult.PASS;
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state,
                                                                    BlockEntityType<T> type) {
        if (level.isClientSide) return null;
        RegistryObject<BlockEntityType<VendingMachineBlockEntity>> expected = ModBlockEntities.VENDING_MACHINE;
        if (type == expected.get()) {
            return (lvl, pos, st, be) -> VendingMachineBlockEntity.serverTick(lvl, pos, st, (VendingMachineBlockEntity) be);
        }
        return null;
    }

    /** Возможный лут автомата */
    public static ItemStack randomSnack(java.util.Random random) {
        int i = random.nextInt(5);
        return switch (i) {
            case 0 -> PotionUtils.setPotion(new ItemStack(Items.POTION), Potions.WATER); // бутылка воды
            case 1 -> new ItemStack(Items.BREAD);       // "консервы"/еда
            case 2 -> new ItemStack(Items.COOKED_BEEF);
            case 3 -> new ItemStack(Items.APPLE);
            default -> new ItemStack(Items.DRIED_KELP); // "снек"
        };
    }
}
