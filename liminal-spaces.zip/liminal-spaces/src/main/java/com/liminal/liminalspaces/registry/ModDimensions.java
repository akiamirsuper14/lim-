package com.liminal.liminalspaces.registry;

import com.liminal.liminalspaces.LiminalSpaces;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;

import java.util.List;

public class ModDimensions {
    public static final ResourceKey<Level> PLAYGROUND = levelKey("playground");
    public static final ResourceKey<Level> HALLWAY = levelKey("hallway");
    public static final ResourceKey<Level> DESERT_ROAD = levelKey("desert_road");
    public static final ResourceKey<Level> AIRPLANE = levelKey("airplane");
    public static final ResourceKey<Level> MEADOW = levelKey("meadow");

    /** Порядок прохождения 1 -> 2 -> 3 -> 4 -> 5 */
    public static final List<ResourceKey<Level>> ORDER =
            List.of(PLAYGROUND, HALLWAY, DESERT_ROAD, AIRPLANE, MEADOW);

    public static final ResourceKey<Biome> PLAYGROUND_BIOME = biomeKey("playground");
    public static final ResourceKey<Biome> HALLWAY_BIOME = biomeKey("hallway");
    public static final ResourceKey<Biome> DESERT_ROAD_BIOME = biomeKey("desert_road");
    public static final ResourceKey<Biome> AIRPLANE_BIOME = biomeKey("airplane");
    public static final ResourceKey<Biome> MEADOW_BIOME = biomeKey("meadow");

    public static boolean isLiminal(ResourceKey<Level> dim) {
        return ORDER.contains(dim);
    }

    public static ResourceKey<Level> next(ResourceKey<Level> dim) {
        int i = ORDER.indexOf(dim);
        return (i >= 0 && i < ORDER.size() - 1) ? ORDER.get(i + 1) : null;
    }

    public static ResourceKey<Level> previous(ResourceKey<Level> dim) {
        int i = ORDER.indexOf(dim);
        return (i > 0) ? ORDER.get(i - 1) : null;
    }

    private static ResourceKey<Level> levelKey(String name) {
        return ResourceKey.create(Registries.DIMENSION, new ResourceLocation(LiminalSpaces.MODID, name));
    }

    private static ResourceKey<Biome> biomeKey(String name) {
        return ResourceKey.create(Registries.BIOME, new ResourceLocation(LiminalSpaces.MODID, name));
    }
}
