package com.liminal.liminalspaces.registry;

import com.liminal.liminalspaces.LiminalSpaces;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModCreativeTab {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, LiminalSpaces.MODID);

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("tab", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.liminalspaces"))
            .icon(() -> ModBlocks.PORTAL_FORWARD.get().asItem().getDefaultInstance())
            .displayItems((params, output) -> ModBlocks.ITEMS.getEntries()
                    .forEach(e -> output.accept(e.get())))
            .build());

    public static void register(IEventBus bus) {
        TABS.register(bus);
    }
}
